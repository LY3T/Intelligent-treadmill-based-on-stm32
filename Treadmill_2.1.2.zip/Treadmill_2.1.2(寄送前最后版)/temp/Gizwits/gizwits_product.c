/**
************************************************************
* @file         gizwits_product.c
* @brief        Gizwits control protocol processing, and platform-related hardware initialization 
* @author       Gizwits
* @date         2017-07-19
* @version      V03030000
* @copyright    Gizwits
*
* @note         Gizwits is only for smart hardware
*               Gizwits Smart Cloud for Smart Products
*               Links | Value Added | Open | Neutral | Safety | Own | Free | Ecology
*               www.gizwits.com
*
***********************************************************/
#include <stdio.h>
#include <string.h>
#include "gizwits_product.h"

#include "led.h"

#include "control.h"

//第一处，添加
#include "usart3.h"

//第八处，修改与添加
extern dataPoint_t currentDataPoint;//用户区当前设备状态结构体

extern u8 wifi_sta;                 //WIFI连接状态，wifi_sta 0: 断开 1: 已连接

extern u8 speed_table[];            //速度值的枚举值

extern int Target_velocity;         //设定速度控制的目标速度为50个脉冲每10ms，目标速度，调控速度的上级参数，相对稳定

extern u8 test_num;                 //测试用

extern int giz_velocity;            //机智云app获取的目标速度，只有app改变才发生改变，相对稳定

extern u8 giz_timing_enum;          //APP定时值的枚举下标

extern u8 Target_timing_enum;       //目标定时值的下标

extern u8 change_flag;              //调控标志

extern u8 moto_run_flag;            //电机运行标志 1：运行 0：停止

extern u8 timing_change_flag;       //定时值发生时改变的标志值 1：发生了改变但目标值没有更新 0：目标值已更新


static uint32_t timerMsCount;

/** Current datapoint */
//dataPoint_t currentDataPoint;

/**@} */
/**@name Gizwits User Interface
* @{
*/

/**
* @brief Event handling interface

* Description:

* 1. Users can customize the changes in WiFi module status

* 2. Users can add data points in the function of event processing logic, such as calling the relevant hardware peripherals operating interface

* @param [in] info: event queue
* @param [in] data: protocol data
* @param [in] len: protocol data length
* @return NULL
* @ref gizwits_protocol.h
*/
int8_t gizwitsEventProcess(eventInfo_t *info, uint8_t *gizdata, uint32_t len)
{
  uint8_t i = 0;
  dataPoint_t *dataPointPtr = (dataPoint_t *)gizdata;
  moduleStatusInfo_t *wifiData = (moduleStatusInfo_t *)gizdata;
  protocolTime_t *ptime = (protocolTime_t *)gizdata;
  
#if MODULE_TYPE
  gprsInfo_t *gprsInfoData = (gprsInfo_t *)gizdata;
#else
  moduleInfo_t *ptModuleInfo = (moduleInfo_t *)gizdata;
#endif

  if((NULL == info) || (NULL == gizdata))
  {
    return -1;
  }

  for(i=0; i<info->num; i++)
  {
    switch(info->event[i])
    {
      case EVENT_LED:
        currentDataPoint.valueLED = dataPointPtr->valueLED;
        GIZWITS_LOG("Evt: EVENT_LED %d \n", currentDataPoint.valueLED);
        if(0x01 == currentDataPoint.valueLED)
        {
          //user handle
			LED0=0;
        }
        else
        {
          //user handle    
			LED0=1;
        }
        break;
      case EVENT_per_dev:
        currentDataPoint.valueper_dev = dataPointPtr->valueper_dev;
        GIZWITS_LOG("Evt: EVENT_per_dev %d \n", currentDataPoint.valueper_dev);
        if(0x01 == currentDataPoint.valueper_dev)
        {
          //user handle
			LED1=0;
        }
        else
        {
          //user handle    
			LED1=1;
        }
        break;
      case EVENT_motor:
        currentDataPoint.valuemotor = dataPointPtr->valuemotor;
        GIZWITS_LOG("Evt: EVENT_motor %d \n", currentDataPoint.valuemotor);
        if(0x01 == currentDataPoint.valuemotor)
        {
          //user handle
			moto_start();
        }
        else
        {
          //user handle    
			moto_stop();
        }
        break;
      case EVENT_timing:
        currentDataPoint.valuetiming = dataPointPtr->valuetiming;
        GIZWITS_LOG("Evt: EVENT_timing %d \n", currentDataPoint.valuetiming);
        if(0x01 == currentDataPoint.valuetiming)
        {
          //user handle
			timing_start();
        }
        else
        {
          //user handle  
			timing_stop();
        }
        break;
      case EVENT_voice:
        currentDataPoint.valuevoice = dataPointPtr->valuevoice;
        GIZWITS_LOG("Evt: EVENT_voice %d \n", currentDataPoint.valuevoice);
        if(0x01 == currentDataPoint.valuevoice)
        {
          //user handle
        }
        else
        {
          //user handle    
        }
        break;

      case EVENT_speed_enum:
        currentDataPoint.valuespeed_enum = dataPointPtr->valuespeed_enum;
        GIZWITS_LOG("Evt: EVENT_speed_enum %d\n", currentDataPoint.valuespeed_enum);
       

	  
//		switch(currentDataPoint.valuespeed_enum)
//        {
//          case speed_enum_VALUE0:
//            //user handle
//            break;
//          case speed_enum_VALUE1:
//            //user handle
//            break;
//          case speed_enum_VALUE2:
//            //user handle
//            break;
//          case speed_enum_VALUE3:
//            //user handle
//            break;
//          case speed_enum_VALUE4:
//            //user handle
//            break;
//          case speed_enum_VALUE5:
//            //user handle
//            break;
//          case speed_enum_VALUE6:
//            //user handle
//            break;
//          default:
//            break;
//        }
        break;
      case EVENT_timing_enum:
        currentDataPoint.valuetiming_enum = dataPointPtr->valuetiming_enum;
        GIZWITS_LOG("Evt: EVENT_timing_enum %d\n", currentDataPoint.valuetiming_enum);

		giz_timing_enum = currentDataPoint.valuetiming_enum;

		if(Target_timing_enum!=giz_timing_enum)
		{
		  Target_timing_enum = giz_timing_enum;
		  
		  timing_change_flag = 1;
		}
	  
//        switch(currentDataPoint.valuetiming_enum)
//        {
//          case timing_enum_VALUE0:
//            //user handle
//            break;
//          case timing_enum_VALUE1:
//            //user handle
//            break;
//          case timing_enum_VALUE2:
//            //user handle
//            break;
//          case timing_enum_VALUE3:
//            //user handle
//            break;
//          case timing_enum_VALUE4:
//            //user handle
//            break;
//          case timing_enum_VALUE5:
//            //user handle
//            break;
//          default:
//            break;
//        }
        break;

      case EVENT_speed_num:
        currentDataPoint.valuespeed_num = dataPointPtr->valuespeed_num;
        GIZWITS_LOG("Evt:EVENT_speed_num %d\n",currentDataPoint.valuespeed_num);
        //user handle
		giz_velocity = currentDataPoint.valuespeed_num;
	  
		if(Target_velocity != giz_velocity)
		{
			if(moto_run_flag!=0)
			{
				Target_velocity = giz_velocity;
				change_flag=1;	
			}
		}	
	  
        break;
      case EVENT_timing_num:
        currentDataPoint.valuetiming_num = dataPointPtr->valuetiming_num;
        GIZWITS_LOG("Evt:EVENT_timing_num %d\n",currentDataPoint.valuetiming_num);
        //user handle
        break;


      case WIFI_SOFTAP:
        break;
      case WIFI_AIRLINK:
        break;
      case WIFI_STATION:
        break;
      case WIFI_CON_ROUTER:
 
        break;
      case WIFI_DISCON_ROUTER:
 
        break;
      case WIFI_CON_M2M:wifi_sta=1;//wifi设备已连接//第二处，添加
 
        break;
      case WIFI_DISCON_M2M:wifi_sta=0;//wifi设备断开//第三处，添加
        break;
      case WIFI_RSSI:
        GIZWITS_LOG("RSSI %d\n", wifiData->rssi);
        break;
      case TRANSPARENT_DATA:
        GIZWITS_LOG("TRANSPARENT_DATA \n");
        //user handle , Fetch data from [data] , size is [len]
        break;
      case WIFI_NTP:
        GIZWITS_LOG("WIFI_NTP : [%d-%d-%d %02d:%02d:%02d][%d] \n",ptime->year,ptime->month,ptime->day,ptime->hour,ptime->minute,ptime->second,ptime->ntp);
        break;
      case MODULE_INFO:
            GIZWITS_LOG("MODULE INFO ...\n");
      #if MODULE_TYPE
            GIZWITS_LOG("GPRS MODULE ...\n");
            //Format By gprsInfo_t
      #else
            GIZWITS_LOG("WIF MODULE ...\n");
            //Format By moduleInfo_t
            GIZWITS_LOG("moduleType : [%d] \n",ptModuleInfo->moduleType);
      #endif
    break;
      default:
        break;
    }
  }

  return 0;
}

/**
* User data acquisition

* Here users need to achieve in addition to data points other than the collection of data collection, can be self-defined acquisition frequency and design data filtering algorithm

* @param none
* @return none
*/
void userHandle(void)
{
 /*
    currentDataPoint.valuespeed_cur = ;//Add Sensor Data Collection
    currentDataPoint.valuespeed_tar = ;//Add Sensor Data Collection
    currentDataPoint.valueHeart_Rate = ;//Add Sensor Data Collection
    currentDataPoint.valuesp02_num = ;//Add Sensor Data Collection
    currentDataPoint.valuewarning = ;//Add Sensor Data Collection

    */
    
}

/**
* Data point initialization function

* In the function to complete the initial user-related data
* @param none
* @return none
* @note The developer can add a data point state initialization value within this function
*/
void userInit(void)
{
    memset((uint8_t*)&currentDataPoint, 0, sizeof(dataPoint_t));
    
    /** Warning !!! DataPoint Variables Init , Must Within The Data Range **/ 
    /*
      currentDataPoint.valueLED = ;
      currentDataPoint.valueper_dev = ;
      currentDataPoint.valuemotor = ;
      currentDataPoint.valuetiming = ;
      currentDataPoint.valuevoice = ;
      currentDataPoint.valuespeed_enum = ;
      currentDataPoint.valuetiming_enum = ;
      currentDataPoint.valuespeed_num = ;
      currentDataPoint.valuetiming_num = ;
      currentDataPoint.valuespeed_cur = ;
      currentDataPoint.valuespeed_tar = ;
      currentDataPoint.valueHeart_Rate = ;
      currentDataPoint.valuesp02_num = ;
      currentDataPoint.valuewarning = ;
    */

}


/**
* @brief  gizTimerMs

* millisecond timer maintenance function ,Millisecond increment , Overflow to zero

* @param none
* @return none
*/
void gizTimerMs(void)
{
    timerMsCount++;
}

/**
* @brief gizGetTimerCount

* Read system time, millisecond timer

* @param none
* @return System time millisecond
*/
uint32_t gizGetTimerCount(void)
{
    return timerMsCount;
}

/**
* @brief mcuRestart

* MCU Reset function

* @param none
* @return none
*/
void mcuRestart(void)
{
    __set_FAULTMASK(1);//关闭所有中断
    NVIC_SystemReset();//复位
}
/**@} */

/**
* @brief TIMER_IRQ_FUN

* Timer Interrupt handler function

* @param none
* @return none
*/
void TIMER_IRQ_FUN(void)
{
  gizTimerMs();
}

/**
* @brief UART_IRQ_FUN

* UART Serial interrupt function ，For Module communication

* Used to receive serial port protocol data between WiFi module

* @param none
* @return none
*/
void UART_IRQ_FUN(void)
{
  uint8_t value = 0;
  //value = USART_ReceiveData(USART2);//STM32 test demo
  gizPutData(&value, 1);
}


/**
* @brief uartWrite

* Serial write operation, send data to the WiFi module

* @param buf      : Data address
* @param len       : Data length
*
* @return : Not 0,Serial send success;
*           -1，Input Param Illegal
*/
int32_t uartWrite(uint8_t *buf, uint32_t len)
{
    uint32_t i = 0;
    
    if(NULL == buf)
    {
        return -1;
    }
    
    #ifdef PROTOCOL_DEBUG
    GIZWITS_LOG("MCU2WiFi[%4d:%4d]: ", gizGetTimerCount(), len);
    for(i=0; i<len; i++)
    {
        GIZWITS_LOG("%02x ", buf[i]);
    }
    GIZWITS_LOG("\n");
    #endif

    for(i=0; i<len; i++)
    {
        //USART_SendData(UART, buf[i]);//STM32 test demo
        //Serial port to achieve the function, the buf[i] sent to the module
		
		//第五处，添加
		USART_SendData(USART3,buf[i]);
        while(USART_GetFlagStatus(USART3,USART_FLAG_TC)==RESET); //循环发送,直到发送完毕
		
        if(i >=2 && buf[i] == 0xFF)
        {
          //Serial port to achieve the function, the 0x55 sent to the module
          //USART_SendData(UART, 0x55);//STM32 test demo
			
		  //第六处，添加
		  USART_SendData(USART3,0x55);
          while(USART_GetFlagStatus(USART3,USART_FLAG_TC)==RESET); //循环发送,直到发送完毕 
	
        }
    }


    
    return len;
}


