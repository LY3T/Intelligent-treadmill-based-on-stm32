#ifndef __CONTROL_H
#define __CONTROL_H
#include "sys.h"
  /**************************************************************************
���ߣ�ƽ��С��֮��
�ҵ��Ա�С�꣺http://shop114407458.taobao.com/
**************************************************************************/
#define PI 3.14159265

//��ʱʱ��ṹ��
typedef struct 
{
	vu8 hour;
	vu8 min;
	vu8 sec;				 
}show_timing_obj;

extern show_timing_obj show_timing;

int  TIM5_IRQHandler(void); 
int myabs(int a);
void Set_Pwm(int moto);
void Xianfu_Pwm(void);
int Incremental_PI (int Encoder,int Target);
int Read_Encoder(u8 TIMX);

void PID_M1_SetVelocity(int Velocity);

void PID_M1_SetKp(float dKpp);

void PID_M1_SetKi(float dKii);

void moto_start(void);

void moto_stop(void);

void speed_change(void);

void distance_count(void);

void speed_change_setting(u8 set_SPEED_CHANGE_TIME,u8 set_change_stop_error,u8 set_change_interval);

void timing(void);

void timing_start(void);

void timing_stop(void);

void get_timing_time(void);

void taximeter_start(void);

void taximeter_stop(void);

void taximeter(void);

void warnning(void);

#endif

