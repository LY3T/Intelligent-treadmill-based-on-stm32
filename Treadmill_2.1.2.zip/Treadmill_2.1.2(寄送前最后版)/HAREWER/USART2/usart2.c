#include "stdio.h"	
#include "stdarg.h"
#include "sys.h"
#include "usart2.h"	

/*
STM32F103VCT6与SYN6288硬件接口非常简单，采用串口通讯方式，

PA9(USART/TX)-->SYN6288_RX(芯片RX引脚需要外接个电平转换,我画的测试板上已经有转换电路了)
PA10(USART/RX)<--SYN6288_TX
PE2(PIN1),<---> SYN6288_BUSY  (可不接)

调用示例：
TTSPlay('m',"欢迎光临xxxx休闲娱乐中心");        

*/ 

/***********************************************
声音播放代码,实现自动计算校验值
第一参数:提示音乐音类型，具体参考官方示例程序
第二参数:播放的文本内容
（SoundVol是个音量值的全局变量）
************************************************/
void TTSPlay(u8 bgm,u8 SoundVol,char *Text,...)
{
        va_list arg_ptr;
        u8 i=0,xorcrc=0,uLen;
        u8 SoundBuf[140];                                        //操作语音提示缓冲 
        char  tmpBuf[120];                                        //
        uLen = (u8)vsprintf(tmpBuf, Text, arg_ptr);
        for (i=0;i<140;i++) SoundBuf[i]=0x00;
        SoundBuf[0]=0xFD;					//帧头
        SoundBuf[1]=0x00;					//数据长度高位
		SoundBuf[2]=uLen+8;				//数据长度低位 *除帧头及数据区长度帧以外的所有字节，不包括数据区长度帧本身(即具体为命令字，命令参数，待发送文本，异或校验)
        SoundBuf[3]=0x01;					//命令字 1：合成语音
		SoundBuf[4]=bgm<<3;					//命令参数 0：无背景音乐 1~15：其他背景音乐
        SoundBuf[5]='[';
        SoundBuf[6]='v';
        SoundBuf[7]=SoundVol/10+0x30;
        SoundBuf[8]=SoundVol%10+0x30;
        SoundBuf[9]=']';
//        SoundBuf[10]=0x73;					//'s'
//        SoundBuf[11]=0x6F;					//'o'
//        SoundBuf[12]=0x75;					//'u'
//        SoundBuf[13]=0x6E;					//'n'
//        SoundBuf[14]=0x64;					//'d'
//        SoundBuf[15]=sound;                //有效值a-v,函数的第一个参数，声音提示之前的音乐声
//        SoundBuf[16]=0x2C;					//','
        for (i=0;i<uLen;i++)
        {
                SoundBuf[10+i]=tmpBuf[i];				//拼接
        }
        for (i=0;i<uLen+10;i++)
        {
                xorcrc=xorcrc ^ SoundBuf[i];			//计算异或校验码
                USART_Send_Byte(SoundBuf[i]);			//发送数据
        }
        USART_Send_Byte(xorcrc);						//发送异或校验码
}

void TTS_printf(u8 bgm,u8 SoundVol,char* fmt,...)
{
	va_list ap; 
	u8 i=0,xorcrc=0,uLen;
	u8 SoundBuf[140];                                        //操作语音提示缓冲 
	char  tmpBuf[120]; 	
	va_start(ap,fmt);
	uLen = vsprintf((char*)tmpBuf,fmt,ap);
	va_end(ap);	                                  //
	for (i=0;i<140;i++) SoundBuf[i]=0x00;
	SoundBuf[0]=0xFD;					//帧头
	SoundBuf[1]=0x00;					//数据长度高位
	SoundBuf[2]=uLen+8;				//数据长度低位 *除帧头及数据区长度帧以外的所有字节，不包括数据区长度帧本身(即具体为命令字，命令参数，待发送文本，异或校验)
	SoundBuf[3]=0x01;					//命令字 1：合成语音
	SoundBuf[4]=bgm<<3;					//命令参数 0：无背景音乐 1~15：其他背景音乐
	SoundBuf[5]='[';
	SoundBuf[6]='v';
	SoundBuf[7]=SoundVol/10+0x30;
	SoundBuf[8]=SoundVol%10+0x30;
	SoundBuf[9]=']';
//        SoundBuf[10]=0x73;					//'s'
//        SoundBuf[11]=0x6F;					//'o'
//        SoundBuf[12]=0x75;					//'u'
//        SoundBuf[13]=0x6E;					//'n'
//        SoundBuf[14]=0x64;					//'d'
//        SoundBuf[15]=sound;                //有效值a-v,函数的第一个参数，声音提示之前的音乐声
//        SoundBuf[16]=0x2C;					//','
	for (i=0;i<uLen;i++)
	{
			SoundBuf[10+i]=tmpBuf[i];				//拼接
	}
	for (i=0;i<uLen+10;i++)
	{
			xorcrc=xorcrc ^ SoundBuf[i];			//计算异或校验码
			USART_Send_Byte(SoundBuf[i]);			//发送数据
	}
	USART_Send_Byte(xorcrc);


	
	
	
}



/***************************
串口配置函数
***************************/
void USART_Configuration(void)
{
        GPIO_InitTypeDef GPIO_InitStructure;
        USART_InitTypeDef USART_InitStructure;
        RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_AFIO, ENABLE);
        RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);
        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
        GPIO_Init(GPIOA, &GPIO_InitStructure);
        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
        GPIO_Init(GPIOA, &GPIO_InitStructure);
        USART_InitStructure.USART_BaudRate = 9600;
        USART_InitStructure.USART_WordLength = USART_WordLength_8b;
        USART_InitStructure.USART_StopBits = USART_StopBits_1;
        USART_InitStructure.USART_Parity = USART_Parity_No;
        USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
        USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
        USART_Init(USART2, &USART_InitStructure);
        USART_Cmd(USART2, ENABLE);
        USART_ClearFlag(USART2, USART_FLAG_TC);
	
        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
        GPIO_Init(GPIOA, &GPIO_InitStructure);		
	
	
}


/***************************************************************************
参数说明：mydata待发送的数据
返回说明：无
***************************************************************************/
void USART_Send_Byte(u8 mydata)
{           
        USART_ClearFlag(USART2,USART_FLAG_TC); 
        USART_SendData(USART2, mydata); 
        while(USART_GetFlagStatus(USART2,USART_FLAG_TC)==RESET);
        USART_ClearFlag(USART2,USART_FLAG_TC);
}
